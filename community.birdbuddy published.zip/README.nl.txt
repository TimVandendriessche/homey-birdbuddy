Haal je Bird Buddy slimme voederhuisje in je smart home. Bekijk het batterijniveau van je feeder, toon de laatste bezoekersfoto en video op je Homey-dashboard en start flows zodra er een nieuwe vogel langskomt.

Log in met het e-mailadres en wachtwoord van je Bird Buddy-account. Accounts die alleen met Google of Facebook inloggen werken niet: maak een account met wachtwoord aan en nodig dat uit voor je feeder in de Bird Buddy-app.

Deze app is niet gemaakt of ondersteund door Bird Buddy. Hij gebruikt dezelfde verbinding als de Bird Buddy-app, dus hij kan stoppen met werken als Bird Buddy daar iets aan verandert. Nieuwe bezoekers worden gezien op het controle-interval dat je bij de apparaatinstellingen instelt, standaard 15 minuten.
