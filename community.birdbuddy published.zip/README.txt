Bring your Bird Buddy smart bird feeder into your smart home. See the battery level of your feeder, get the latest visitor photo and video on your Homey dashboard, and start flows whenever a new bird stops by.

Log in with the email address and password of your Bird Buddy account. Accounts that only use Google or Facebook sign-in cannot be used: create an account with a password and invite it to your feeder in the Bird Buddy app.

This app is not made or supported by Bird Buddy. It uses the same connection as the Bird Buddy app, so it can stop working if Bird Buddy changes it. New visitors are detected at the check interval you set in the device settings, 15 minutes by default.
